import json
import boto3
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    """
    A Lambda function that returns all records from the 'Records' table
    for a given userId using the 'UserID-MachineID-index' global index.

    The event JSON is expected to look like:
    {
      "queryStringParameters": {
        "userId": "123e4567-e89b-12d3-a456-426614174000"
      }
    }
    """

    # Safely retrieve userId from queryStringParameters
    query_params = event.get('queryStringParameters') or {}
    user_id = query_params.get('userId')

    if not user_id:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Missing userId in queryStringParameters."})
        }

    # Initialize the DynamoDB client
    dynamodb = boto3.client('dynamodb')

    # Set your table and index names
    table_name = "Records"
    index_name = "UserID-index"

    try:
        # Perform the DynamoDB query on the specified GSI
        response = dynamodb.query(
            TableName=table_name,
            IndexName=index_name,
            KeyConditionExpression="UserID = :uid",
            ExpressionAttributeValues={
                ":uid": {"S": user_id}
            }
        )
        
        items = response.get("Items", [])

        # Convert DynamoDB item format to a plain dictionary (optional, but more readable)
        def convert_dynamodb_item(dynamo_item):
            return {k: list(v.values())[0] for k, v in dynamo_item.items()}

        records = [convert_dynamodb_item(item) for item in items]

        return {
            "statusCode": 200,
            "body": json.dumps({
                "records": records
            }),
            "headers": {
                "Content-Type": "application/json"
            }
        }

    except ClientError as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)}),
            "headers": {
                "Content-Type": "application/json"
            }
        }
