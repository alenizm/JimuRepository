import json
import boto3

# יצירת חיבור ל-DynamoDB
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('WorkingPlans')  # שמו של הטבלה ב-DynamoDB

def lambda_handler(event, context):
    try:
        # קבלת פרטי המשתמש והתוכנית מתוך הבקשה
        user_id = event.get('UserID')  # שימוש ב-get כדי להימנע משגיאות אם השדה לא קיים
        plan_id = event.get('PlanID')  # שימוש ב-get כדי להימנע משגיאות אם השדה לא קיים

        # בדיקת קיום המידע
        if not user_id or not plan_id:
            return {
                'statusCode': 400,
                'body': json.dumps('UserID or PlanID is missing')  # מחזיר כ-JSON תקני
            }

        # ביצוע המחיקה בטבלה
        response = table.delete_item(
            Key={
                'UserID': user_id,
                'PlanID': plan_id
            }
        )

        # בדיקה אם המחיקה הצליחה
        if response.get('ResponseMetadata', {}).get('HTTPStatusCode') == 200:
            return {
                'statusCode': 200,
                'body': 'Plan deleted successfully'  # לא צריך להשתמש ב- json.dumps כאן
            }
        else:
            return {
                'statusCode': 500,
                'body': 'Failed to delete plan'  # לא צריך להשתמש ב- json.dumps כאן
            }
    
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': 'Error occurred during deletion'  # לא צריך להשתמש ב- json.dumps כאן
        }
