import json
import boto3
from botocore.exceptions import ClientError

# Initialize the DynamoDB client
dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    # Specify your DynamoDB table name
    table_name = "Records"
    table = dynamodb.Table(table_name)
    
    # Extract the partition key from the event (query string or body)
    partition_key_name = "RecordID"  # Replace with your table's partition key name
    partition_key_value = event.get('queryStringParameters', {}).get(partition_key_name)
    
    if not partition_key_value:
        return {
            "statusCode": 400,
            "body": json.dumps({"error": f"Missing {partition_key_name} in request"})
        }
    
    try:
        # Perform the delete operation
        response = table.delete_item(
            Key={partition_key_name: partition_key_value}
        )
        return {
            "statusCode": 200,
            "body": json.dumps({"message": "Item deleted successfully"})
        }
    except ClientError as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
