import json
import decimal
import boto3
from boto3.dynamodb.conditions import Key

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, decimal.Decimal):
            # Convert Decimal to float or int here
            return float(obj)
        return super(DecimalEncoder, self).default(obj)


def lambda_handler(event, context):
    try:
        body = json.loads(event["body"])
        User_id = body["UserID"]
    except (KeyError, TypeError, json.JSONDecodeError):
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Missing or invalid userID in request body"})
        }
    
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('WorkingPlans')

    try:
        response = table.query(KeyConditionExpression=Key('UserID').eq(User_id))
        items = response.get('Items', [])
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }

    # Use the custom encoder
    return {
        "statusCode": 200,
        "body": json.dumps(items, cls=DecimalEncoder)
    }
