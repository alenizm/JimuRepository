import boto3
import logging

# Initialize the logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize the Cognito Identity Provider client
cognito_idp = boto3.client("cognito-idp")

def lambda_handler(event, context):
    try:
        # Extract details from the event
        user_pool_id = event["userPoolId"]
        user_name = event["userName"]
        group_name = "trainees"  # Default group name

        # Add the user to the group
        response = cognito_idp.admin_add_user_to_group(
            UserPoolId=user_pool_id,
            Username=user_name,
            GroupName=group_name
        )

        logger.info(f"Successfully added user {user_name} to group {group_name}")
        return event  # Return the event to indicate success

    except Exception as e:
        logger.error(f"Error adding user to group: {e}")
        raise Exception("Failed to add user to default group.")
