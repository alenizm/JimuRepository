import json
import boto3
from botocore.exceptions import ClientError
from datetime import datetime
import uuid

# Create a DynamoDB resource
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Records')

def lambda_handler(event, context):
    try:
        # Check if event['body'] is already a dict, if not, parse it
        if isinstance(event['body'], str):
            body = json.loads(event['body'])
        else:
            body = event['body']  # It's already a dictionary
        
        # Extract fields from the parsed body
        UserID = body.get('UserID')
        MachineName = body.get("MachineName")
        MachineID = body.get('MachineID')
        Repetitions = body.get('Repetitions')
        Set = body.get('Set')
        Weight = body.get('Weight')

        # Validate that all required fields are present
        if not (UserID and MachineID and Repetitions and Set and Weight and MachineName):
            return {
                'statusCode': 400,
                'body': json.dumps({'message': 'All fields are required.'}),
            }

        # Create a unique RecordID
        RecordID = str(uuid.uuid4())

        # Add record to DynamoDB
        timestamp = datetime.utcnow().isoformat()
        response = table.put_item(
            Item={
                'UserID': UserID,
                'MachineName': MachineName,
                'MachineID': MachineID,
                'Repetitions': str(Repetitions),
                'Set': str(Set),
                'Weight': str(Weight),
                'Timestamp': timestamp,
                'RecordID': RecordID
            }
        )

        # Check the response to ensure the item was added successfully
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            return {
                'statusCode': 200,
                'body': json.dumps({'message': 'Workout saved successfully!'}),
            }
        else:
            return {
                'statusCode': 500,
                'body': json.dumps({'message': 'Failed to save workout to the database.'}),
            }

    except ClientError as e:
        print(f"Error saving workout record: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'An error occurred while saving the workout.'}),
        }
    except Exception as e:
        print(f"Unexpected error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'An unexpected error occurred.'}),
        }
