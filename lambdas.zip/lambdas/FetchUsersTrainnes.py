import json
import boto3
from botocore.exceptions import ClientError

# Initialize the Cognito client
client = boto3.client("cognito-idp")

def lambda_handler(event, context):
    try:
        # Extract parameters from the query string
        user_pool_id = event["queryStringParameters"]["UserPoolId"]
        group_name = event["queryStringParameters"]["GroupName"]

        # List users in the specified group
        response = client.list_users_in_group(
            UserPoolId=user_pool_id,
            GroupName=group_name
        )
        
        # Extract relevant user information
        users = []
        for user in response["Users"]:
            user_info = {
                "username": user["Username"],
                "email": next(
                    (attr["Value"] for attr in user["Attributes"] if attr["Name"] == "email"), None
                ),
                "sub": next(
                    (attr["Value"] for attr in user["Attributes"] if attr["Name"] == "sub"), None
                ),
            }
            users.append(user_info)

        # Return the list of users
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json"
            },
            "body": json.dumps(users)
        }

    except KeyError as e:
        # Handle missing parameters
        return {
            "statusCode": 400,
            "headers": {
                "Content-Type": "application/json"
            },
            "body": json.dumps({"error": f"Missing required parameter: {str(e)}"})
        }

    except ClientError as e:
        # Handle AWS errors
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json"
            },
            "body": json.dumps({"error": str(e)})
        }

    except Exception as e:
        # Handle generic errors
        return {
            "statusCode": 500,
            "headers": {
                "Content-Type": "application/json"
            },
            "body": json.dumps({"error": str(e)})
        }
