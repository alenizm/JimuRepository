import json
import os
import boto3
import uuid
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail

def format_plan_details(plan_details):
    """Format the plan details into a human-readable format."""
    formatted_details = []
    for machine in plan_details:
        machine_name = machine.get("machine", "Unknown Machine")
        sets = machine.get("sets", [])
        formatted_details.append(f"{machine_name}:")
        for idx, set_detail in enumerate(sets, start=1):
            weight = set_detail.get("weight", "N/A")
            repetitions = set_detail.get("reps", "N/A")
            formatted_details.append(f"  Set {idx}: Weight: {weight}, Repetitions: {repetitions}")
    return "\n".join(formatted_details)

def lambda_handler(event, context):
    # Log the event for debugging
    print(f"Received event: {json.dumps(event)}")

    # Safely parse the body
    body = event.get("body", {})
    if isinstance(body, str):
        body = json.loads(body)

    # Extract required fields from the body
    user_email = body.get("UserEmail")
    trainer_id = body.get("TrainerID")
    user_id = body.get("UserID")
    plan_details = body.get("PlanDetails")
    trainer_name = body.get("TrainerName")

    # Validate required fields
    if not user_email or not trainer_id or not user_id or not plan_details or not trainer_name :
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "UserEmail, TrainerID, UserID, and PlanDetails are required fields."})
        }

    # Generate a unique PlanID
    plan_id = str(uuid.uuid4())

    # Format the plan details
    formatted_plan_details = format_plan_details(plan_details)

    # Prepare email content
    message = Mail(
        from_email="a206624256a@gmail.com",  # Replace with your verified sender email
        to_emails=user_email,
        subject="Your Working Plan is Ready!",
        plain_text_content=(f"Hello,\n\n"
                            f"Your trainer {trainer_name} has created a working plan for you.\n\n"
                            f"Plan Details:\n{formatted_plan_details}\n\n"
                            f"Best regards,\nFitness App Team")
    )

    try:
        # Send email using SendGrid
        sg = SendGridAPIClient(os.environ.get("SG_API_KEY"))
        response = sg.send(message)
        print(f"Email sent successfully: {response.status_code}")
    except Exception as e:
        print(f"Error sending email: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Failed to send email.", "details": str(e)})
        }

    try:
        # Save message details to DynamoDB
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('WorkingPlans')
        table.put_item(
            Item={
                'UserID': user_id,
                'TrainerName': trainer_name,
                'UserEmail': user_email,
                'TrainerID': trainer_id,
                'PlanDetails': plan_details,
                'PlanID': plan_id
            }
        )
        print(f"Message saved to DynamoDB table 'WorkingPlans' successfully.")
    except Exception as e:
        print(f"Error saving message to DynamoDB: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": "Failed to save message to DynamoDB.", "details": str(e)})
        }

    return {
        "statusCode": 200,
        "body": json.dumps({"message": f"Email sent successfully to {user_email} and saved to DynamoDB.", "PlanID": plan_id})
    }
