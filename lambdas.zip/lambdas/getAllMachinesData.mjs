import { DynamoDBClient, ScanCommand } from "@aws-sdk/client-dynamodb";
import { unmarshall } from "@aws-sdk/util-dynamodb";

const dynamoDB = new DynamoDBClient({});

export const handler = async (event) => {
  const params = {
    TableName: "Machines", // החלף בשם הטבלה שלך
  };

  try {
    const command = new ScanCommand(params);
    const data = await dynamoDB.send(command);

    // המרת הפריטים לפורמט ידידותי
    const items = data.Items.map((item) => unmarshall(item));

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify(items), // הפלט המותאם
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Error fetching data" }),
    };
  }
};
