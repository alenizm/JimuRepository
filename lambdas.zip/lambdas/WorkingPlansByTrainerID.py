import json
import decimal
import boto3
from boto3.dynamodb.conditions import Key

class DecimalEncoder(json.JSONEncoder):
    """Helper class to convert DynamoDB's Decimal to float for JSON serialization."""
    def default(self, obj):
        if isinstance(obj, decimal.Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    try:
        body = json.loads(event["body"])
        Trainer_id = body["TrainerID"]
    except (KeyError, TypeError, json.JSONDecodeError):
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Missing or invalid trainerID in request body"})
        }
    
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('WorkingPlans')
    
    try:
        response = table.query(
            IndexName='trainer-user-work-plans', 
            KeyConditionExpression=Key('TrainerID').eq(Trainer_id)
        )
        items = response.get('Items', [])
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }

    return {
        "statusCode": 200,
        "body": json.dumps(items, cls=DecimalEncoder)
    }
